export const SportsIDs = {
    tennis_WTA: 21318426,
    tennis_ATP: 34907300,
    soccer_spanish: 16954963,
    soccer_german: 89130637,
    soccer_italian: 79449277,
    soccer_uefa: 35403285,
    soccer_australian: 76381880
};