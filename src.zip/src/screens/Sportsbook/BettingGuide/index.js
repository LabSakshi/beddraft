import React from "react";
import LiveBetting from "../../Rules/Livebetting";
const BettingGuide = () => {
  return <LiveBetting />;
};

export default BettingGuide;
