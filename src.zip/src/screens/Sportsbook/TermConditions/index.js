import React from "react";
import TermsAndconditions from "../../Rules/Termsconditions";
const Termsconditions = () => {
  return <TermsAndconditions />;
};

export default Termsconditions;
