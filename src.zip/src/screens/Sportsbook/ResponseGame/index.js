import React from "react";
import ResponsibleGaming from "../../Rules/Responsiblegaming";
const ResponseGame = () => {
  return <ResponsibleGaming />;
};

export default ResponseGame;
