import "./race.css";

const RaceBook = () => {
  return (
    <div style={{justifyContent:'center',display:'flex',marginTop:'100px'}}>
      <h1 style={{color:'white'}}>SportsBook Coming Soon .....</h1>
    </div>
  );
};

export default RaceBook;
