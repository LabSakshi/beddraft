import "./home.css";

import Header from "../../components/Header";

import SideBar from "../../components/SideBar";
const Home = () => {
  return (
    <div>
      {/* <h1>home compoenent</h1> */}
      {/* <Header />
      <SideBar /> */}
    </div>
  );
};

export default Home;
