import React from 'react';

function MyIframe() {
  return (
    <iframe
      title="My iframe"
      src="https://app.prizepicks.com"
      width="100%"
      height="500px"
      allowFullScreen
    />
  );
}

export default MyIframe;
